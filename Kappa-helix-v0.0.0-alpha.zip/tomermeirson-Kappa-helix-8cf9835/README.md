# Kappa-helix

Protein structural assignment of the secondary structure k-helix (commonly known as polyproline type II helix) 
